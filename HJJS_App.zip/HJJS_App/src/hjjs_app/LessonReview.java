package hjjs_app;

import java.util.ArrayList;
import java.util.List;

public class LessonReview {

    private Student student;
    private BookingManagement booking;
    private int ratingId;
    private String studentName;
    private int studentId;
    private String lessonCode;
    private String lessonName;
    private String teacherName;
    private String ratingDate;
    private String ratingDay;
    private String rating;
    private String review;
    private List<LessonReview> reviewDetails;

    public int getRatingId() {
        return ratingId;
    }

    public void setRatingId(int ratingId) {
        this.ratingId = ratingId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getLessonCode() {
        return lessonCode;
    }

    public void setLessonCode(String lessonCode) {
        this.lessonCode = lessonCode;
    }

    public String getLessonName() {
        return lessonName;
    }

    public void setLessonName(String lessonName) {
        this.lessonName = lessonName;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getRatingDate() {
        return ratingDate;
    }

    public void setRatingDate(String ratingDate) {
        this.ratingDate = ratingDate;
    }

    public String getRatingDay() {
        return ratingDay;
    }

    public void setRatingDay(String ratingDay) {
        this.ratingDay = ratingDay;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public List<LessonReview> getReviewDetails() {
        return reviewDetails;
    }

    public void setReviewDetails(List<LessonReview> reviewDetails) {
        this.reviewDetails = reviewDetails;
    }

    public LessonReview(int ratingId, String studentName, int studentId, String lessonCode, String lessonName, String teacherName, String ratingDate, String ratingDay, String rating, String review) {
        this.ratingId = ratingId;
        this.studentName = studentName;
        this.studentId = studentId;
        this.lessonCode = lessonCode;
        this.lessonName = lessonName;
        this.teacherName = teacherName;
        this.ratingDate = ratingDate;
        this.ratingDay = ratingDay;
        this.rating = rating;
        this.review = review;
    }

    public LessonReview(Student student, BookingManagement booking) {
        reviewDetails = new ArrayList<>();
        this.student = student;
        this.booking = booking;
    }
    //save review details of user given
    public void saveReviewDetails(int studentId, String bookingId, String rating, String review1) {
        int ratingId = reviewDetails.size() + 1;
        String studentName = student.getStudentById(studentId).getStuName();
        String lessonCode = booking.getBookingDetailsById(bookingId).getLessonCode();
        String lessonName = booking.getBookingDetailsById(bookingId).getLessonName();
        String teacherName = booking.getBookingDetailsById(bookingId).getTeacherName();
        String ratingDate = new LessonDetails().getLesssonDetailsById(lessonCode).getLessonDate();
        String ratingDay = new LessonDetails().getLesssonDetailsById(lessonCode).getLessonDay();
        //save Review details in list
        reviewDetails.add(new LessonReview(ratingId, studentName, studentId, lessonCode, lessonName, teacherName, ratingDate, ratingDay, rating, review1));
    }

    //show review details 
    public void showReviewDetails(int studentId) {
        String reviewCode;
        int headingShow = 0;
        String reviewDescription;
        //check reviewDetails is empty or not
        if (userReview(studentId)) {
            //show heading
            System.out.println("\n-------------------------------------------------------------------------------------------"
                    + "------------------------------------------------------------");
            System.out.println("|\t\t\t\t\t\t\t\tReview Details\t\t\t\t\t\t\t\t|");
            System.out.println("-------------------------------------------------------------------------------------------"
                    + "------------------------------------------------------------");
            System.out.printf("%-15s%-15s%-15s%-15s%-15s%-15s%-15s%-15s%-15s\n", "| Review Code ", "| Student Name ",
                    "| Lesson Code ", "| Lesson Name ", "| Teacher ", "| Review Date ", "| Review Day ", "| Rating ", "Review Description");
            System.out.println("-------------------------------------------------------------------------------------------"
                    + "------------------------------------------------------------");
            for (LessonReview review1 : reviewDetails) {
                //get rating details by id or all student
                if (studentId == 0 || review1.getStudentId() == studentId) {
                    headingShow++;
                    studentName = review1.getStudentName();
                    lessonCode = review1.getLessonCode();
                    lessonName = review1.getLessonName();
                    teacherName = review1.getTeacherName();
                    reviewCode = (studentName.substring(0, 3) + lessonName.substring(0, 3) + "_0" + review1.getRatingId()).toUpperCase();
                    ratingDate = review1.getRatingDate();
                    ratingDay = review1.getRatingDay();
                    rating = review1.getRating();
                    reviewDescription = review1.getReview();
                    System.out.printf("%-15s%-15s%-15s%-15s%-15s%-15s%-15s%-15s%-15s\n", "| " + reviewCode, "| " + studentName,
                            "| " + lessonCode, "| " + lessonName, "| " + teacherName, "| " + ratingDate, "| " + ratingDay, "| " + rating, "| " + reviewDescription + " |");
                    System.out.println("-------------------------------------------------------------------------------------------"
                            + "------------------------------------------------------------");

                }
            }
        } else {
            System.out.println("Review details is empty");
        }
    }
    
    
    //check user review is not empty
    public boolean userReview(int studentId) {
        for (LessonReview review1 : reviewDetails) {
            if (review1.getStudentId() == studentId) {
                return true;
            }
        }
        return false;
    }

}
