package hjjs_app;

import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LessonDetails {

    private Teacher teacher;
    private String lessonCode;
    private String lessonTitle;
    private String lessonDate;
    private String lessonDay;
    private String lessonTime;
    private int lessonLevel;
    private String lessonTeacher;
    private String teacherGender;
    private String numOfSeats;
    private List<LessonDetails> lessonDetails;

    public String getLessonCode() {
        return lessonCode;
    }

    public void setLessonCode(String lessonCode) {
        this.lessonCode = lessonCode;
    }

    public String getLessonTitle() {
        return lessonTitle;
    }

    public void setLessonTitle(String lessonTitle) {
        this.lessonTitle = lessonTitle;
    }

    public String getLessonDate() {
        return lessonDate;
    }

    public void setLessonDate(String lessonDate) {
        this.lessonDate = lessonDate;
    }

    public String getLessonDay() {
        return lessonDay;
    }

    public void setLessonDay(String lessonDay) {
        this.lessonDay = lessonDay;
    }

    public String getLessonTime() {
        return lessonTime;
    }

    public void setLessonTime(String lessonTime) {
        this.lessonTime = lessonTime;
    }

    public int getLessonLevel() {
        return lessonLevel;
    }

    public void setLessonLevel(int lessonLevel) {
        this.lessonLevel = lessonLevel;
    }

    public String getLessonTeacher() {
        return lessonTeacher;
    }

    public void setLessonTeacher(String lessonTeacher) {
        this.lessonTeacher = lessonTeacher;
    }

    public String getTeacherGender() {
        return teacherGender;
    }

    public void setTeacherGender(String teacherGender) {
        this.teacherGender = teacherGender;
    }

    public String getNumOfSeats() {
        return numOfSeats;
    }

    public void setNumOfSeats(String numOfSeats) {
        this.numOfSeats = numOfSeats;
    }

    public List<LessonDetails> getLessons() {
        return lessonDetails;
    }

    public LessonDetails(String lessonCode, String lessonTitle, String lessonDate, String lessonDay, String lessonTime, int lessonLevel, String lessonTeacher, String teacherGender, String numOfSeats) {
        this.lessonCode = lessonCode;
        this.lessonTitle = lessonTitle;
        this.lessonDate = lessonDate;
        this.lessonDay = lessonDay;
        this.lessonTime = lessonTime;
        this.lessonLevel = lessonLevel;
        this.lessonTeacher = lessonTeacher;
        this.teacherGender = teacherGender;
        this.numOfSeats = numOfSeats;
    }

    public LessonDetails() {
        lessonDetails = new ArrayList<>();
        teacher = new Teacher();
        setLessons();
    }

    public void setLessons() {
        String id;
        String title;
        String date;
        String day;
        int level;
        String teacherName;
        String gender;
        String teacherGender;
        String time;
        String numOfSeat;
        CSVReader reader = null;
        try {
            //fetch details from csv file
            reader = new CSVReader(new FileReader("src/hjjs_app/csv_file/lessonDetails.csv"));
            String[] details = null;
            //skip header
            reader.readNext();
            while ((details = reader.readNext()) != null) {
                id = details[0];
                title = details[1];
                day = details[2];
                level = Integer.parseInt(details[3]);
                teacherName = details[4];
                date = details[5];
                time = details[6];
                numOfSeat = details[7];
                teacherGender = teacher.getTeacherDetailsByName(teacherName).getGender();
                //store details in arraylist
                lessonDetails.add(new LessonDetails(id, title, date, day, time, level, teacherName, teacherGender, numOfSeat));

            }
        } catch (IOException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public LessonDetails getLesssonDetailsById(String lessonCode) {
        LessonDetails lesson1 = null;
        for (LessonDetails lesson : lessonDetails) {
            if (lesson.getLessonCode().equalsIgnoreCase(lessonCode)) {
                lesson1 = lesson;
            }
        }
        return lesson1;
    }

}
