package hjjs_app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TimeTable {

    private int grade;
    private String day;
    private Scanner scanner;
    private String filter = null;
    private LessonDetails lesson;
    private Student student;
    private String[] dayList = {"Monday", "Wednesday", "Friday", "Saturday"};
    private List<LessonDetails> lessonDetails;
    private List<LessonDetails> filterTimeTable;

    public List<LessonDetails> getFilterTimeTable() {
        return filterTimeTable;
    }

    public void setFilterTimeTable(List<LessonDetails> filterTimeTable) {
        this.filterTimeTable = filterTimeTable;
    }

    public TimeTable(LessonDetails lesson) {
        filterTimeTable = new ArrayList<>();
        scanner = new Scanner(System.in);
        student = new Student();
        this.lesson = lesson;
    }

    //show timetable
    public void showTimeTable() {
        lessonDetails = lesson.getLessons();
        LessonDetailsFactory factory = new LessonDetailsFactory();

        // Store all lesson details in filterTimeTable if it is empty
        if (filterTimeTable.isEmpty()) {
            for (LessonDetails lessonDetail : lessonDetails) {
                filterTimeTable.add(lessonDetail);
            }
        } else if (filter == null) {
            //clear time table before adding new details
            filterTimeTable.clear();
            for (LessonDetails lesson1 : lessonDetails) {
                //add all new details in filterTimeTable
                filterTimeTable.add(lesson1);
            }
        }
        // Show details
        System.out.println("------------------------------------------------------------------------------------------------------------------------------"
                + "--------------------------------");
        System.out.printf("%-12s%-30s%-15s%-15s%-12s%-15s%-10s%-10s%-20s%-30s\n", "|  Lesson Code", "  |  \t Lesson Title   ", "| Lesson Day  ",
                "| Lesson Grade ", "| Lesson Teacher ", "|  Lesson Date ", "|  Seat ", "| Teacher Gender ", "|  Lesson Time  ", "|");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------"
                + "--------------------------------");

        // Show all lesson details
        for (LessonDetails filterLessonDetail : filterTimeTable) {
            // Use the factory to create LessonDetails objects
            LessonDetails lessonDetail = factory.createLessonDetails(filterLessonDetail);
            String lessonCode = lessonDetail.getLessonCode();
            String lessonTitle = lessonDetail.getLessonTitle();
            String lessonDay = lessonDetail.getLessonDay();
            int lessonLevel = lessonDetail.getLessonLevel();
            String lessonTime = lessonDetail.getLessonTime();
            String lessonTeacher = lessonDetail.getLessonTeacher();
            String teacherGender = lessonDetail.getTeacherGender();
            String lessonDate = lessonDetail.getLessonDate();
            String numOfSeat = lessonDetail.getNumOfSeats();
            System.out.printf("%-12s%-30s%-15s%-15s%-15s%-17s%-10s%-10s%-20s%-30s\n", "|   " + lessonCode, "    | " + lessonTitle, "\t| " + lessonDay, "| Level " + lessonLevel,
                    "|  " + lessonTeacher, "  | " + lessonDate, "|  " + numOfSeat + " ", " |\t" + teacherGender + " ", "|   " + lessonTime, "  |");
        }
        System.out.printf("%-157s%-1s\n", "|", "|");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------"
                + "--------------------------------");
        filter = null;
    }

    //filter time table
    public void filterTimeTable(int studentId) {
        showTimeTable();
        String dayInput;
        String gradeInput;
        String teacherInput;
        boolean validOption = false;

        //show option for selecting
        System.out.println("\n* Select one option to view filter timetable\n");
        System.out.println("1. Filter by grade");
        System.out.println("2. Filter by day");
        System.out.println("3. Filter by teacher");
        while (!validOption) {
            //get option to filter timetable from user
            System.out.print("Enter your option : ");
            filter = scanner.nextLine().trim();
            if (filter.matches("[1-3]")) {
                switch (filter) {
                    case "1" -> {
                        for (;;) {
                            //filter time table according to grade
                            System.out.print("Enter Grade : ");
                            gradeInput = scanner.nextLine().trim();
                            //validation of grade input by user
                            if (gradeInput.matches("[1-5]")) {
                                //clear filterTableTable to add new details
                                filterTimeTable.clear();
                                grade = Integer.parseInt(gradeInput);
                                for (LessonDetails lesson1 : lessonDetails) {
                                    //get lesson details by grade
                                    if (lesson1.getLessonLevel() == grade) {
                                        filterTimeTable.add(lesson1);
                                    }
                                }
                                //show lesson details after adding filter lesson details in filterTimeTable
                                showTimeTable();
                                break;
                            } else {
                                //show error message after enter wrong grade
                                System.out.println("Enter valid grade");
                            }

                        }
                    }
                    case "2" -> {
                        System.out.print("Enter one day name from (");
                        for (String day : dayList) {
                            System.out.print(day + "/");
                        }
                        System.out.println(") this day list");
                        for (;;) {
                            //get day name to filter timetable by user
                            System.out.print("Enter Day : ");
                            dayInput = scanner.nextLine().trim();
                            //validation of valid day enter by user
                            if (validDay(dayInput)) {
                                //clear filterTimeTable before adding new filter details
                                filterTimeTable.clear();
                                for (LessonDetails lesson1 : lessonDetails) {
                                    day = lesson1.getLessonDay();
                                    //get lesson details by day
                                    if (day.equalsIgnoreCase(dayInput) || day.substring(0, 3).equalsIgnoreCase(dayInput)) {
                                        filterTimeTable.add(lesson1);
                                    }
                                }
                                //show timetable after filterTimeTable
                                showTimeTable();
                                break;
                            } else {
                                //show errro message if user enter wrong day name
                                System.out.println("Enter valid day");
                            }

                        }
                    }
                    case "3" -> {
                        System.out.println("\nSelect one teacher name from below teacher table");
                        //shoe teacher details
                        new Teacher().showTeacherDetails();
                        for (;;) {
                            //get teacher name to filter timetable by user
                            System.out.print("Enter Teacher Name : ");
                            teacherInput = scanner.nextLine().trim();
                            //validation of teacher is exist or not
                            if (isTeacherExist(teacherInput)) {
                                //clear time table before adding new details
                                filterTimeTable.clear();
                                for (LessonDetails lesson1 : lessonDetails) {
                                    //get lesson detais by teacher name
                                    if (lesson1.getLessonTeacher().equalsIgnoreCase(teacherInput)) {
                                        //add new details in filterTimeTable
                                        filterTimeTable.add(lesson1);
                                    }
                                }
                                //show timetable
                                showTimeTable();
                                break;
                            } else {
                                //show error message after enter wrong grade by user
                                System.out.println("Enter valid teacher name");
                            }
                        }
                    }

                }
                validOption = true;
            } else {
                //show error message after enter wrong input
                System.out.println("Error : please enter valid option");
                if (studentId != 0) {
                    return;
                }
            }
        }

        //ask from uset do apply refilter in timetable
        applyRefilterTimetable(studentId);
    }

    //take input from user to refilter time table
    public void applyRefilterTimetable(int studentId) {
        String option;
        boolean validInput = false;
        while (!validInput) {
            //ask to refilter timetable from student
            System.out.print("Want to book a class (Yes/No) : ");
            option = scanner.nextLine().trim();
            //validation of user input
            if (option.equalsIgnoreCase("Y") || option.equalsIgnoreCase("Yes")) {
                validInput = true;
            } else {
                filterTimeTable(studentId);
                validInput = true;
            }
        }
    }

    public String selectLesson() {
        String inputLesson = null;
        boolean validLesson = false;
        //get lesson code from input if user select option no
        System.out.println("\n* Select one lesson code from above timetable\n");
        while (!validLesson) {
            System.out.print("Enter Lesson Code : ");
            inputLesson = scanner.nextLine().trim();
            //validation of enter lesson code
            if (!inputLesson.matches("^(?i)(MON|WED|FRI|SAT)_(0[1-9]|1[0-2])$")) {
                System.out.println("Please enter valid lesson code ");
                validLesson = true;
            } else {
                validLesson = true;
            }
        }
        return inputLesson;
    }

    //factory method to create lessonDetails object  
    private static class LessonDetailsFactory {

        public LessonDetails createLessonDetails(LessonDetails lessonDetail) {
            // return objects
            return new LessonDetails(lessonDetail.getLessonCode(), lessonDetail.getLessonTitle(),
                    lessonDetail.getLessonDate(), lessonDetail.getLessonDay(),
                    lessonDetail.getLessonTime(), lessonDetail.getLessonLevel(),
                    lessonDetail.getLessonTeacher(), lessonDetail.getTeacherGender(),
                    lessonDetail.getNumOfSeats());
        }
    }

    //check day given by user is valid or not
    public boolean validDay(String dayInput) {
        for (String day : dayList) {
            if (day.equalsIgnoreCase(dayInput) || day.substring(0, 3).equalsIgnoreCase(dayInput)) {
                return true;
            }
        }
        return false;
    }

    //check teacher name input by user is exist
    public boolean isTeacherExist(String teacherName) {
        List<Teacher> teacherList = new Teacher().getTeacherDetails();
        for (Teacher teacher : teacherList) {
            if (teacher.getFullName().equalsIgnoreCase(teacherName)) {
                return true;
            }
        }
        return false;
    }

}
