package hjjs_app;

import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Teacher {

    private int teacherId;
    private String fullName;
    private String email;
    private String contact;
    private String dateOfBirth;
    private String gender;
    private List<Teacher> teacherDetails;

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public List<Teacher> getTeacherDetails() {
        return teacherDetails;
    }

    public Teacher(int teacherId, String fullName, String email, String contact, String dateOfBirth, String gender) {
        this.teacherId = teacherId;
        this.fullName = fullName;
        this.email = email;
        this.contact = contact;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
    }

    public Teacher() {
        teacherDetails = new ArrayList<>();
        setTeacherDetails();

    }

    public void setTeacherDetails() {
        int id;
        String name;
        String email;
        String contact;
        String dateOfBirth;
        String gender;
        CSVReader reader = null;
        try {
            //fetch details from csv file
            reader = new CSVReader(new FileReader("src/hjjs_app/csv_file/userDetails.csv"));
            String[] details = null;
            //skip header
            reader.readNext();
            while ((details = reader.readNext()) != null) {
                if (details[6].equalsIgnoreCase("Teacher")) {
                    id = Integer.parseInt(details[0]);
                    name = details[1];
                    email = details[2];
                    gender = details[3];
                    dateOfBirth = details[5];
                    contact = details[7];
                    //store details in arraylist
                    teacherDetails.add(new Teacher(id, name, email, contact, dateOfBirth, gender));
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Teacher getTeacherDetailsByName(String name) {
        Teacher teacher = null;
        for (Teacher teacher1 : teacherDetails) {
            if (teacher1.getFullName().equalsIgnoreCase(name)) {
                teacher = teacher1;
            }
        }
        return teacher;

    }

    public void showTeacherDetails() {
         System.out.println("\n-----------------------------------------------------------------------------------------------"
                + "---------------------------------------");
            System.out.println("|\t\t\t\t\t\t\t\tTeacher Details\t\t\t\t\t\t\t\t|");
           System.out.println("\n-----------------------------------------------------------------------------------------------"
                + "---------------------------------------");
        System.out.println("-----------------------------------------------------------------------------------------------"
                + "-----------------------------------------------------");
        System.out.printf("%-15s%-25s%-25s%-15s%-15s%-15s\n", "|\tTeacher Id", "|\t\tTeacher Name", "|\t\tEmail",
                "|\t   Contact\t    ", "|\tDate Of Birth\t  ", "|\tGender\t|");
        System.out.println("-----------------------------------------------------------------------------------------------"
                + "-----------------------------------------------------");
        for (Teacher teacher : teacherDetails) {
            System.out.printf("%-15s%-25s%-25s%-15s%-15s%-15s\n", "|\t" + teacher.teacherId, "|\t\t" + teacher.fullName, "|\t\t" + teacher.email,
                    "|\t   " + teacher.contact + "\t    ", "|\t" + teacher.dateOfBirth + "\t", "|\t" + teacher.gender + "\t|");
        }
        System.out.println("-----------------------------------------------------------------------------------------------"
                + "-----------------------------------------------------");
    }

}
