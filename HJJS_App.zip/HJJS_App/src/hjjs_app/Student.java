package hjjs_app;

import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Student {

    private int stuId;
    private String stuName;
    private String stuEmail;
    private String stuGender;
    private int stuLevel;
    private int stuAge = 0;
    private String stuContact;
    private String stuPassword;
    private String adminContact = "04123451234";
    private String adminPassword = "12345";
    private List<Student> studentDetails;
    private Scanner scanner;

    public int getStuId() {
        return stuId;
    }

    public void setStuId(int stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public String getStuEmail() {
        return stuEmail;
    }

    public void setStuEmail(String stuEmail) {
        this.stuEmail = stuEmail;
    }

    public String getStuGender() {
        return stuGender;
    }

    public void setStuGender(String stuGender) {
        this.stuGender = stuGender;
    }

    public int getStuLevel() {
        return stuLevel;
    }

    public void setStuLevel(int stuLevel) {
        this.stuLevel = stuLevel;
    }

    public int getStuAge() {
        return stuAge;
    }

    public void setStuAge(int stuAge) {
        this.stuAge = stuAge;
    }

    public String getStuContact() {
        return stuContact;
    }

    public void setStuContact(String stuContact) {
        this.stuContact = stuContact;
    }

    public String getStuPassword() {
        return stuPassword;
    }

    public void setStuPassword(String stuPassword) {
        this.stuPassword = stuPassword;
    }

    public List<Student> getStudentDetails() {
        return studentDetails;
    }

    public void setStudentDetails(List<Student> studentDetails) {
        this.studentDetails = studentDetails;
    }

    public Student(int stuId, String stuName, String stuEmail, String stuGender, int stuLevel, int stuAge, String stuContact, String stuPassword) {
        this.stuId = stuId;
        this.stuName = stuName;
        this.stuEmail = stuEmail;
        this.stuGender = stuGender;
        this.stuLevel = stuLevel;
        this.stuAge = stuAge;
        this.stuContact = stuContact;
        this.stuPassword = stuPassword;
    }

    public Student() {
        studentDetails = new ArrayList();
        scanner = new Scanner(System.in);
        preRegisteredStudents();
    }

    //save preRegisterStudemt details
    public void preRegisteredStudents() {
        int id;
        String name;
        String email;
        String gender;
        String contact;
        int level;
        int age;
        String password;
        CSVReader reader = null;
        try {
            //fetch details from csv file
            reader = new CSVReader(new FileReader("src/hjjs_app/csv_file/userDetails.csv"));
            String[] details = null;
            //skip header
            reader.readNext();
            while ((details = reader.readNext()) != null) {
                if (details[6].equalsIgnoreCase("Student")) {
                    id = Integer.parseInt(details[0]);
                    name = details[1];
                    email = details[2];
                    gender = details[3];
                    level = Integer.parseInt(details[4]);
                    age = Integer.parseInt(details[5]);
                    contact = details[7];
                    password = details[8];
                    //store details in arraylist
                    studentDetails.add(new Student(id, name, email, gender, level, age, contact, password));
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void studentRegister() {
        //generate random id by get studentDetails size
        int id = studentDetails.size() + 1;
        String name = null;
        String ageInput;
        String email = null;
        String contact = null;
        String gender = null;
        String levelInput;
        String password = null;
        boolean duplicateContact = true;
        int minAge = 4;
        int maxAge = 11;
        System.out.println("*-----------------------------------------------*");
        System.out.println("|\t\tRegistration Form\t\t|");
        System.out.println("*-----------------------------------------------*");
        for (;;) {
            //get student name
            if (name == null || !name.matches("[a-zA-Z]+") || !(name.length() >= 4)) {
                System.out.print("Enter Student Name : ");
                name = scanner.nextLine();
                if (!name.matches("[a-zA-Z]+")) {
                    //show message if name field is empty
                    System.out.println("Name field cannot be empty");
                } else if (!(name.length() >= 4)) {
                    System.out.println("Name should be minimum 4 characters");
                }
                //get user email
            } else if (email == null || !email.matches("^(.+)@(\\S+)$")) {
                System.out.print("Enter Student Email : ");
                email = scanner.nextLine();
                if (!email.matches("^(.+)@(\\S+)$")) {
                    System.out.println("Please enter valid email id");
                }
                //get student age
            } else if (stuAge == 0 || !validAge(stuAge)) {
                System.out.print("Enter Student Age : ");
                ageInput = scanner.nextLine().trim();
                if (ageInput.matches("[0-9]+")) {
                    stuAge = Integer.parseInt(ageInput);
                    if (!validAge(stuAge)) {
                        //show message if student doest not enter valid age
                        System.out.println("Invalid : Student age should be 4 to 11 years ");
                    }
                } else {
                    //show message if student doest not enter valid age
                    System.out.println("Invalid : Student age should be 4 to 11 years ");
                }
                //get student contact details by user
            } else if (contact == null || !contact.matches("[0-9]+") || duplicateContact) {
                System.out.print("Enter Student Contact : ");
                contact = scanner.nextLine().trim();
                duplicateContact = isContactExist(contact);
                if (duplicateContact) {
                    System.out.println("This contact already registered");
                }
                //get student gender details by user
            } else if (gender == null || !(gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female") || gender.equalsIgnoreCase("M") || gender.equalsIgnoreCase("F"))) {
                System.out.print("Enter Student Gender : ");
                gender = scanner.nextLine().trim();
                //get student level by user
            } else if (stuLevel == 0 || !(stuLevel >= 1 && stuLevel <= 5)) {
                System.out.print("Enter Student Level : ");
                levelInput = scanner.nextLine();
                if (levelInput.matches("[1-5]")) {
                    stuLevel = Integer.parseInt(levelInput);
                } else {
                    //show message if user does not enter valid level
                    System.out.println("Invalid : Enter valid student level 1 to 5");
                }
                //get student password by user
            } else if (password == null || password.matches("^(?=\\s*$)")) {
                System.out.print("Enter Student Password : ");
                password = scanner.nextLine().trim();
            } else {
                //save new student details in studentDetails list

                studentDetails.add(new Student(id, name, email, gender, stuLevel, stuAge, contact, password));
                System.out.println("Registration Successfull\n");
                //set stuLevel and stuAge instance variable 0 after successfully saved details
                stuLevel = 0;
                stuAge = 0;
                break;
            }
        }

    }

    //get student details by id
    public Student getStudentById(int id) {
        Student student = null;
        for (Student student1 : studentDetails) {
            //filter student object by id
            if (student1.getStuId() == id) {
                student = student1;
            }
        }
        //student object
        return student;
    }

    //
    public int studentLogin() {
        String option = null;
        String contact = null;
        String password = null;
        boolean isLogin = false;
        System.out.println("*-----------------------------------------------*");
        System.out.println("|\t* Select one option from below list\t|");
        System.out.println("*-----------------------------------------------*");
        System.out.println("1. Login");
        System.out.println("2. Register (If you are a new student)");
        System.out.println("3. Exit");
        System.out.println();
        System.out.println();
        do {
            System.out.print("Enter your Option : ");
            option = scanner.nextLine().trim();
            if (option == null || !option.matches("[1-3]")) {
                System.out.println("Invalid option. Please enter a valid option (1-3).");
            } else {
                switch (option) {
                    case "1" -> {
                        System.out.println("*-----------------------------------------------*");
                        System.out.println("|\t\tLogin Form\t\t\t|");
                        System.out.println("*-----------------------------------------------*");
                        while (!isLogin) {
                            System.out.print("Enter Contact : ");
                            contact = scanner.nextLine().trim();

                            System.out.print("Enter Password : ");
                            password = scanner.nextLine().trim();

                            for (Student student : studentDetails) {
                                if (student.getStuContact().equals(contact) && student.getStuPassword().equals(password)) {
                                    stuId = student.getStuId();
                                    isLogin = true;
                                } else if (adminContact.equalsIgnoreCase(contact) && adminPassword.equalsIgnoreCase(password)) {
                                    stuId = 10001;
                                    isLogin = true;
                                }
                            }
                            if (!isLogin) {
                                System.out.println("Error: Incorrect contact or password");
                            } else {
                                System.out.println("Login Successful\n");
                            }
                        }
                    }
                    case "2" -> {
                        studentRegister();
                    }
                    default -> {
                        System.exit(0);
                    }
                }
            }
        } while (!option.matches("[1-3]"));
        return stuId;
    }

    public void showStudentDetails() {
        String stuId;
        String stuName;
        String stuEmail;
        String stuGender;
        int stuLevel;
        int stuAge = 0;
        String stuContact;

        System.out.println("\n-----------------------------------------------------------------------------------------------"
                + "---------------------------------------");
        System.out.println("|\t\t\t\t\t\t\t\tStudent Details\t\t\t\t\t\t\t\t|");
        System.out.println("\n-----------------------------------------------------------------------------------------------"
                + "---------------------------------------");
        System.out.println("\n-----------------------------------------------------------------------------------------------"
                + "---------------------------------------");
        System.out.printf("%-15s%-20s%-10s%-20s%-15s%-10s%-15s\n", "|\tStudent Id", "|\tStudent Name", "|\tLevel", "|\tEmail",
                "|\t   Contact\t    ", "|\tAge ", "|\tGender\t|");
        System.out.println("-----------------------------------------------------------------------------------------------"
                + "---------------------------------------");
        for (Student student : studentDetails) {
            stuName = student.getStuName();
            stuId = stuName.substring(0, 3) + "_0" + student.getStuId();
            stuEmail = student.getStuEmail();
            stuGender = student.getStuGender();
            stuLevel = student.getStuLevel();
            stuAge = student.getStuAge();
            stuContact = student.getStuContact();
            System.out.printf("%-15s%-20s%-10s%-20s%-15s%-10s%-15s\n", "|\t" + stuId, "|\t" + stuName, "|\tLevel " + stuLevel, "|\t" + stuEmail,
                    "|\t   " + stuContact + "\t    ", "|\t" + stuAge, "|\t" + stuGender + "\t|");
        }
        System.out.println("-----------------------------------------------------------------------------------------------"
                + "---------------------------------------");

    }

    //check enter user is unique
    public boolean isContactExist(String contact) {
        for (Student student : studentDetails) {
            if (student.getStuContact().equals(contact) || adminContact.equalsIgnoreCase(contact)) {
                return true;
            }
        }
        return false;
    }

    //check valid age
    public boolean validAge(int age) {
        return age >= 4 && age <= 11;
    }
}
