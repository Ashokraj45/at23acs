package hjjs_app;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookingManagement {

    private String bookingId;
    private int stuId;
    private String stuName;
    private int stuLevel;
    private String lessonCode;
    private String lessonName;
    private String teacherName;
    private int lessonLevel;
    private String bookingDate;
    private String bookingStatus;
    private Student student;
    private LessonDetails lesson;
    private TimeTable timetable;
    private Scanner scanner;
    private List<BookingManagement> bookingDetails;

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public int getStuId() {
        return stuId;
    }

    public void setStuId(int stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public int getStuLevel() {
        return stuLevel;
    }

    public void setStuLevel(int stuLevel) {
        this.stuLevel = stuLevel;
    }

    public String getLessonCode() {
        return lessonCode;
    }

    public void setLessonCode(String lessonCode) {
        this.lessonCode = lessonCode;
    }

    public String getLessonName() {
        return lessonName;
    }

    public void setLessonName(String lessonName) {
        this.lessonName = lessonName;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public int getLessonLevel() {
        return lessonLevel;
    }

    public void setLessonLevel(int lessonLevel) {
        this.lessonLevel = lessonLevel;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public List<BookingManagement> getBookingDetails() {
        return bookingDetails;
    }

    public void setBookingDetails(List<BookingManagement> bookingDetails) {
        this.bookingDetails = bookingDetails;
    }

    public BookingManagement(String bookingId, int stuId, String stuName, int stuLevel, String lessonCode, String lessonName, String teacherName, int lessonLevel, String bookingDate, String bookingStatus) {
        this.bookingId = bookingId;
        this.stuId = stuId;
        this.stuName = stuName;
        this.stuLevel = stuLevel;
        this.lessonCode = lessonCode;
        this.lessonName = lessonName;
        this.teacherName = teacherName;
        this.lessonLevel = lessonLevel;
        this.bookingDate = bookingDate;
        this.bookingStatus = bookingStatus;
    }

    public BookingManagement(Student student, LessonDetails lesson, TimeTable timetable) {
        bookingDetails = new ArrayList<>();
        scanner = new Scanner(System.in);
        this.student = student;
        this.lesson = lesson;
        this.timetable = timetable;
    }

    public boolean lessonBooking(String lessonCode, int studentId) {
        boolean validLessonCode = true;
        // Select lesson if lessonCode is null
        if (lessonCode == null || !lessonCode.matches("^(?i)(MON|WED|FRI|SAT)_(0[1-9]|1[0-2])$")) {
            timetable.filterTimeTable(studentId);
            lessonCode = timetable.selectLesson();
            if (lessonCode.matches("^(?i)(MON|WED|FRI|SAT)_(0[1-9]|1[0-2])$")) {
                validLessonCode = true;
            } else {
                validLessonCode = false;
            }
        }
        if (validLessonCode) {
            // Check for duplicate booking
            if (duplicateBoooking(lessonCode, studentId)) {
                System.out.println("This class has already  booked.");
            } else if (!isValidLevel(lessonCode, studentId)) {
                System.out.println(lessonCode + " class is not for your level.");
            } else if (!checkSeatCapacity(lessonCode)) {
                System.out.println("This lesson seat full");
            } else if (!validLessonCode) {
                System.out.println("Please select valid lesson code");
            } else {
                // Get student details and lesson details to store in booking details
                String stuName = student.getStudentById(studentId).getStuName();
                String lessonName = lesson.getLesssonDetailsById(lessonCode).getLessonTitle();
                String bookingId = stuName.substring(0, 3).toUpperCase() + lessonName.substring(0, 3).toUpperCase() + "_" + (bookingDetails.size() + 1);
                int stuLevel = student.getStudentById(studentId).getStuLevel();
                String teacherName = lesson.getLesssonDetailsById(lessonCode).getLessonTeacher();
                int lessonLevel = lesson.getLesssonDetailsById(lessonCode).getLessonLevel();
                String bookingDate = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
                String status = "Booked";
                // Add the booking to the bookingDetails list
                bookingDetails.add(new BookingManagement(bookingId, studentId, stuName, stuLevel, lessonCode, lessonName, teacherName, lessonLevel, bookingDate, status));
                // Update lesson seat after booking class
                for (LessonDetails lesson1 : lesson.getLessons()) {
                    if (lesson1.getLessonCode().equalsIgnoreCase(lessonCode)) {
                        int currentSeat = Integer.parseInt(lesson1.getNumOfSeats());
                        int updatedSeat = currentSeat - 1;
                        lesson1.setNumOfSeats(String.valueOf(updatedSeat));
                        break;
                    }
                }
                return true;
            }
        }
        return false;
    }

    //change bookng class
    public boolean changeBooking(int studentId) {
        boolean validBookingId = false;
        String oldLessonCode = null;
        String newLessonCode = null;
        String bookingIdInput;
        // Display booking details 
        showBookingDetails(studentId);
        System.out.println(userBooking(studentId));
        if (userBooking(studentId)) {
            do {
                // Get booking id from the user
                System.out.print("Enter Booking Id : ");
                bookingIdInput = scanner.nextLine().trim();
                //validation of booking id
                validBookingId = validBookingId(bookingIdInput);
                if (!validBookingId) {
                    System.out.println("Invalid booking id");
                    validBookingId = true;
                } else {
                    for (BookingManagement booking : bookingDetails) {
                        if (booking.getBookingId().equalsIgnoreCase(bookingIdInput)) {
                            // Check booking is already attended or cancelled or not
                            if (booking.getBookingStatus().equalsIgnoreCase("Attend") || booking.getBookingStatus().equalsIgnoreCase("Cancel")) {
                                validBookingId = true;
                                System.out.println("This booking ID is already attended or cancelled.");

                            } else {
                                //store booking Id
                                bookingId = bookingIdInput;
                                // Store the old lesson code
                                oldLessonCode = getBookingDetailsById(bookingId).getLessonCode();
                                // show filter timetable
                                timetable.showTimeTable();
                                timetable.applyRefilterTimetable(studentId);
                                //select new lesson to change
                                newLessonCode = timetable.selectLesson();
                                // check for duplicate booking
                                if (duplicateBoooking(newLessonCode, studentId)) {
                                    System.out.println("This class has already booked");
                                } else if (!isValidLevel(newLessonCode, studentId)) {
                                    System.out.println(newLessonCode + " class is not for your level.");
                                } else {
                                    // Update booking details
                                    for (BookingManagement booking1 : bookingDetails) {
                                        if (booking1.getBookingId().equalsIgnoreCase(bookingId)) {
                                            booking1.setLessonCode(newLessonCode);
                                            booking1.setLessonName(lesson.getLesssonDetailsById(newLessonCode).getLessonTitle());
                                            booking1.setTeacherName(lesson.getLesssonDetailsById(newLessonCode).getLessonTeacher());
                                            booking1.setLessonLevel(lesson.getLesssonDetailsById(newLessonCode).getLessonLevel());
                                            booking1.setBookingDate(LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy")));
                                            booking1.setBookingStatus("Change");
                                        }
                                    }

                                    // Update seat 
                                    for (LessonDetails lesson1 : lesson.getLessons()) {
                                        if (lesson1.getLessonCode().equalsIgnoreCase(newLessonCode)) {
                                            int currentSeat = Integer.parseInt(lesson1.getNumOfSeats());
                                            int updatedSeat = currentSeat - 1;
                                            lesson1.setNumOfSeats(String.valueOf(updatedSeat));
                                        } else if (lesson1.getLessonCode().equalsIgnoreCase(oldLessonCode)) {
                                            int currentSeat = Integer.parseInt(lesson1.getNumOfSeats());
                                            int updatedSeat = currentSeat + 1;
                                            lesson1.setNumOfSeats(String.valueOf(updatedSeat));
                                        }
                                    }
                                    return true;
                                }

                                validBookingId = true;
                            }
                        }
                    }
                }
            } while (!validBookingId);

        }

        return false;
    }

    //cancel booking 
    public boolean cancelBooking(int studentId) {
        boolean validBookingId = false;
        String bookingIdInput;
        validBookingId = false;
        // Display booking details 
        showBookingDetails(studentId);
        if (userBooking(studentId)) {
            // Get booking id from the user
            System.out.println("* Choose one booking id from above list");
            do {
                System.out.print("Enter Booking Id : ");
                bookingIdInput = scanner.nextLine().trim();
                validBookingId = validBookingId(bookingIdInput);
                if (!validBookingId) {
                    System.out.println("Please enter valid booking id to cancel");
                    validBookingId = true;
                }
            } while (!validBookingId);
            // Cancel the booking
            for (BookingManagement booking : bookingDetails) {
                if (booking.getBookingId().equalsIgnoreCase(bookingIdInput)) {
                    // check bookingid already attend or cancel
                    if (!(booking.getBookingStatus().equalsIgnoreCase("Attend") || booking.getBookingStatus().equalsIgnoreCase("Cancel"))) {
                        String lessonCode = booking.getLessonCode();
                        booking.setBookingStatus("Cancel");
                        // update seat after cancel booking
                        for (LessonDetails lesson1 : lesson.getLessons()) {
                            if (lesson1.getLessonCode().equalsIgnoreCase(lessonCode)) {
                                int currentSeat = Integer.parseInt(lesson1.getNumOfSeats());
                                int updatedSeat = currentSeat + 1;
                                lesson1.setNumOfSeats(String.valueOf(updatedSeat));
                                break;
                            }
                        }
                        return true;
                    } else {
                        // show error if booking id alreay attend or cancelled
                        System.out.println("This booking is already cancelled or attended.");
                    }
                }
            }

        }

        return false;
    }

    //attend booking class
    public boolean attendBooking(LessonReview review, int studentId) {
        String lessonCode;
        boolean validBookingId;
        String bookingIdInput;
        // Display booking details 
        showBookingDetails(studentId);
        if (userBooking(studentId)) {
            do {
                // Get booking id from the user
                System.out.print("Enter Booking Id : ");
                bookingIdInput = scanner.nextLine().trim();
                //validation of booking id
                validBookingId = validBookingId(bookingIdInput);
                if (!validBookingId) {
                    System.out.println("Invalid booking id");
                    validBookingId = true;
                } else {
                    for (BookingManagement booking : bookingDetails) {
                        if (booking.getBookingId().equalsIgnoreCase(bookingIdInput)) {
                            lessonCode = booking.getLessonCode();
                            // check selected bookingid status
                            if (booking.getBookingStatus().equalsIgnoreCase("Attend") || booking.getBookingStatus().equalsIgnoreCase("Cancel")) {
                                validBookingId = false;
                                System.out.println("This booking id is already attended or cancelled.");
                                return false;
                            } else {
                                //get review from student after attend class
                                setReview(review, bookingIdInput);
                                booking.setBookingStatus("Attend");
                                validBookingId = true;
                                //update seat after attend class
                                // Update lesson seat after booking class
                                for (LessonDetails lesson1 : lesson.getLessons()) {
                                    if (lesson1.getLessonCode().equalsIgnoreCase(lessonCode)) {
                                        int currentSeat = Integer.parseInt(lesson1.getNumOfSeats());
                                        int updatedSeat = currentSeat + 1;
                                        lesson1.setNumOfSeats(String.valueOf(updatedSeat));
                                        break;
                                    }
                                }
                                //update level after attend class
                                int lessonLevel = lesson.getLesssonDetailsById(lessonCode).getLessonLevel();
                                int stuCurrentLevel = student.getStudentById(studentId).getStuLevel();
                                if (lessonLevel > stuCurrentLevel) {
                                    for (Student student1 : student.getStudentDetails()) {

                                        if (student1.getStuId() == studentId) {
                                            student1.setStuLevel(lessonLevel);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return true;
                }
            } while (!validBookingId);
        }
        //attend lesson code
        return false;
    }

    //show booking details
    public void showBookingDetails(int studentId) {
        if (userBooking(studentId)) {
            System.out.println("\n---------------------------------------------------------------------------------"
                    + "------------------------------------------------------------------------------------------------------------------------");
            System.out.println("|\t\t\t\t\t\t\t\tBooking Details\t\t\t\t\t\t\t\t|");
            System.out.println("---------------------------------------------------------------------------------"
                    + "------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-10s%-10s%-10s%-10s%-15s%-10s%-10s%-15s%-10s%-15s%-10s%-15s\n", "| Booking Id ",
                    "| Student Name ", "| student Grade ",
                    "| Lesson Code ", "| Lesson Title", "| Lesson Grade  ", "| Teacher Name  ", "| Booking Date  ", "| Booking Status ", "| Lesson Date ", "| Lesson Day ", "| Lesson Duration ");
            System.out.println("-------------------------------------------------------------------------------------------"
                    + "--------------------------------------------------------------------------------------------------------------");

            for (BookingManagement booking : bookingDetails) {
                if (studentId == 0 || booking.getStuId() == studentId) {
                    String bookingId = booking.getBookingId();
                    String stuName = booking.getStuName();
                    int stuGrade = student.getStudentById(booking.getStuId()).getStuLevel();
                    String lessonCode = booking.getLessonCode();
                    String lessonTitle = lesson.getLesssonDetailsById(lessonCode).getLessonTitle();
                    int lessonGrade = booking.getLessonLevel();
                    String teacherName = booking.getTeacherName();
                    String bookingDate = booking.getBookingDate();
                    String bookingStatus = booking.getBookingStatus();
                    String lessonDate = lesson.getLesssonDetailsById(lessonCode).getLessonDate();
                    String lessonDay = lesson.getLesssonDetailsById(lessonCode).getLessonDay();
                    String lessonDuration = lesson.getLesssonDetailsById(lessonCode).getLessonTime();

                    System.out.printf("%-10s%-10s%-10s%-10s%-15s%-10s%-10s%-15s%-10s%-15s%-10s%-15s\n", "|  " + bookingId, "  |   " + stuName, "     |    Grade " + stuGrade,
                            "    |   " + lessonCode, "   | " + lessonTitle, " |    Grade " + lessonGrade, "    |   " + teacherName, "     |   " + bookingDate, "   |  " + bookingStatus, "   |   " + lessonDate, "   |   " + lessonDay, "    |   " + lessonDuration);

                    System.out.println("-------------------------------------------------------------------------------------------"
                            + "--------------------------------------------------------------------------------------------------------------");

                }
            }
        } else {
            System.out.println("Booking details is empty");
        }
    }

    //show selected class
    public void setReview(LessonReview review, String bookingId) {
        int studentId = 0;
        String rating = null;
        String reviewInput;
        String review1 = null;
        String studentName;
        String teacherName;
        String lessonCode;
        String lessonTitle;
        String status;
        String attendDate;
        String attendDay;
        String lessonDuration;
        boolean validReview = false;
        System.out.println("Attend class details");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------"
                + "--------------------------------------------------------------------------");
        System.out.printf("%-10s%-10s%-15s%-10s%-10s%-15s%-10s%-10s%-15s%-20s\n", "| Booking Id |", " Student Id | ", "Student Name | ",
                "Teacher  | ", "Lesson Code | ", "Lesson Title | ", "Status | ", "Attend Date |  ", "Attend Day | ", "Lesson Duration |");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------"
                + "--------------------------------------------------------------------------");
        for (BookingManagement booking3 : bookingDetails) {
            if (booking3.getBookingId().equalsIgnoreCase(bookingId)) {
                studentName = booking3.getStuName();
                studentId = booking3.getStuId();
                teacherName = booking3.getTeacherName();
                lessonCode = booking3.getLessonCode();
                lessonTitle = booking3.getLessonName();
                status = booking3.getBookingStatus();
                attendDate = lesson.getLesssonDetailsById(lessonCode).getLessonDate();
                attendDay = lesson.getLesssonDetailsById(lessonCode).getLessonDay();
                lessonDuration = lesson.getLesssonDetailsById(lessonCode).getLessonTime();
                System.out.printf("%-10s%-10s%-15s%-10s%-10s%-15s%-10s%-10s%-10s%-20s\n", "| " + bookingId, "   | " + studentName.toUpperCase() + "_0" + studentId, "   |    " + studentName,
                        "   | " + teacherName, "    |    " + lessonCode, "  | " + lessonTitle, " | " + status, " | " + attendDate, " | " + attendDay, " | " + lessonDuration + " | ");
            }
            System.out.println("-------------------------------------------------------------------------------------------------------------------------------"
                    + "--------------------------------------------------------------------------");

        }

// Get rating and review after attending class
        do {
            // Get rating from the user
            if (rating == null || !rating.matches("[1-5]")) {
                System.out.print("Enter Rating (1-5) : ");
                rating = scanner.nextLine().trim();
                if (!rating.matches("[1-5]")) {
                    System.out.println("Please enter rating 1 to 5");
                    //set rating null
                    rating = null;
                }
            } else {
                //get review from user
                System.out.print("Enter Review : ");
                reviewInput = scanner.nextLine().trim();
                //check reviweInput is not empty
                if (!reviewInput.isEmpty()) {
                    review1 = reviewInput;
                    //set valid review true
                    validReview = true;
                } else {
                    //show error message
                    System.out.println("Review cannot be empty.");
                }
            }
        } while (!validReview);
        //store review details in arraylist
        review.saveReviewDetails(studentId, bookingId, rating, review1);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------"
                + "--------------------------------------------------------------------------");

    }

    //get booking details by id
    public BookingManagement getBookingDetailsById(String bookingId) {
        BookingManagement booking1 = null;
        for (BookingManagement booking : bookingDetails) {
            if (booking.getBookingId().equalsIgnoreCase(bookingId)) {
                booking1 = booking;
            }
        }
        return booking1;
    }

    //validation of lessonCode and studentId level
    public boolean isValidLevel(String lessonCode, int studentId) {
        int studentLevel = student.getStudentById(studentId).getStuLevel();
        int lessonLevel1 = new LessonDetails().getLesssonDetailsById(lessonCode).getLessonLevel();
        return studentLevel == lessonLevel1 || (studentLevel + 1) == lessonLevel1;
    }

    //validation of duplicate booking
    public boolean duplicateBoooking(String lessonCode, int studentId) {
        for (BookingManagement booking : bookingDetails) {
            if (booking.getLessonCode().equalsIgnoreCase(lessonCode) && booking.getStuId() == studentId) {
                if (!booking.getBookingStatus().equalsIgnoreCase("Cancel")) {
                    return true;
                }
            }

        }
        return false;
    }

    //check bookingId enter by user
    public boolean validBookingId(String bookingId) {
        for (BookingManagement booking : bookingDetails) {
            if (booking.getBookingId().equalsIgnoreCase(bookingId)) {
                return true;
            }
        }
        return false;
    }

    //check seat capacity
    public boolean checkSeatCapacity(String lessonCode) {
        int capacity = 0;
        List<LessonDetails> lessons = lesson.getLessons();
        for (LessonDetails lesson1 : lessons) {
            if (lesson1.getLessonCode().equalsIgnoreCase(lessonCode)) {
                capacity = Integer.parseInt(lesson1.getNumOfSeats());
                if (capacity >= 1 && capacity <= 4) {
                    return true;
                }
            }
        }
        return false;
    }

    //check user booking is not empty
    public boolean userBooking(int studentId) {
        for (BookingManagement booking1 : bookingDetails) {
            if (booking1.getStuId() == studentId) {
                return true;
            }
        }
        return false;
    }

}
