package hjjs_app;

import java.util.Scanner;

public class HJJS_App {

    private int studentId;
    private String lessonCode;
    private Student student;
    private String actionStatus;
    private LessonReview review;
    private LessonDetails lesson;
    private BookingManagement booking;
    private ReportController report;
    private TimeTable timetable;
    private Scanner scanner;

    public HJJS_App() {
        scanner = new Scanner(System.in);
        lesson = new LessonDetails();
        timetable = new TimeTable(lesson);
        student = new Student();
        booking = new BookingManagement(student, lesson, timetable);
        review = new LessonReview(student, booking);
        report = new ReportController();

    }

    //show school info
    public void schoolInfo() {
        System.out.printf("%-35s%-200s\n", "", "\t\t**********************************************************\t\t");
        System.out.printf("%-35s%-208s\n", "", "\t\t*\t\t Welcome to Swimming School\t\t*");
        System.out.printf("%-35s%-200s\n", "", "\t\t**********************************************************");
        System.out.println();
    }

    //start project
    public void Start() {
//        //filter time table and select when app start first time
        if (actionStatus == null) {
            timetable.filterTimeTable(studentId);
            //ask from user to apply refilter
            lessonCode = timetable.selectLesson();
            System.out.println("\n* Please Login to book this class ");
        }

        //login from user and get id
        if (lessonCode.matches("^(?i)(MON|WED|FRI|SAT)_(0[1-9]|1[0-2])$")) {
            userLogin();
        } else {
            Start();
        }
    }

    public void userLogin() {
        studentId = student.studentLogin();
        //get student id 10001 if admin login
        if (studentId == 10001) {
            adminDetails();
            openAdminPanel();
        } else if (studentId != 0) {
            studentDetails();
            openStudentPanel();
        } else {
            userLogin();
        }
    }

    public void studentDetails() {
        System.out.println("*-----------------------------------------------*");
        System.out.println("|\t\tStudent Panel\t\t\t|");
        System.out.println("*-----------------------------------------------*");
        System.out.println("|\tStudent Id    : " + studentId + "\t\t\t|");
        System.out.println("|\tStudent Name  : " + student.getStudentById(studentId).getStuName() + "\t\t\t|");
        System.out.println("|\tStudent Level : " + student.getStudentById(studentId).getStuLevel() + "\t\t\t|");
        System.out.println("|\t\t\t\t\t\t|");
        System.out.println("*-----------------------------------------------*");
    }

    //open student panel after login student
    public void openStudentPanel() {
        String option = null;
        //student
        System.out.println("\n1. Book Lesson");
        System.out.println("2. Cancel Lesson ");
        System.out.println("3. Change Lesson");
        System.out.println("4. Attend Lesson");
        System.out.println("5. View Booking Details");
        System.out.println("6. View Review Details");
        System.out.println("7. Logout");
        //call functionality according to user enter option
        for (;;) {
            if (option == null || !option.matches("[1-7]")) {
                System.out.print("Enter your option : ");
                option = scanner.nextLine().trim();
            } else {
                switch (option) {
                    case "1" -> {
                        boolean result = booking.lessonBooking(lessonCode, studentId);
                        if (result) {
                            System.out.println("Class booked successfully.");
                        }
                        lessonCode = null;
                    }
                    case "2" -> {
                        boolean result = booking.cancelBooking(studentId);
                        if (result) {
                            System.out.println("Booking cancelled successfully.");
                        }
                    }
                    case "3" -> {
                        boolean result = booking.changeBooking(studentId);
                        if (result) {
                            System.out.println("Lesson changed successfully.");
                        }
                    }
                    case "4" -> {
                        boolean result = booking.attendBooking(review, studentId);
                        if (result) {
                            System.out.println("Class attend successfully");
                        }
                    }
                    case "5" -> {
                        booking.showBookingDetails(studentId);
                    }
                    case "6" -> {
                        review.showReviewDetails(studentId);
                    }
                    default -> {
                        //set action status logout 
                        actionStatus = "Logout";
                        studentId = 0;
                        //call user login function after logout successfully
                        userLogin();
                        break;
                    }
                }
                break;
            }

        }
        //recall this function till student id not null
        if (studentId != 0) {
            openStudentPanel();
        }

    }

    public void adminDetails() {
        System.out.println("*-----------------------------------------------*");
        System.out.println("|\t\tAdmin Panel\t\t\t|");
        System.out.println("*-----------------------------------------------*");
    }

    //open admin panel after login admin
    public void openAdminPanel() {
        String status = null;
        boolean validInput = false;
        String input;
        System.out.println("\n1. View Student Details");
        System.out.println("2. View Teacher Details");
        System.out.println("3. View Booking Details");
        System.out.println("4. View Student Report");
        System.out.println("5. View Teacher Report");
        System.out.println("6. View Review Details");
        System.out.println("7. Logout");
        //call functionality according to user enter option
        while (!validInput) {
            System.out.print("Enter your option : ");
            input = scanner.nextLine();
            if (input.matches("[1-7]")) {
                switch (input) {
                    case "1" -> {
                        student.showStudentDetails();
                    }
                    case "2" -> {
                        new Teacher().showTeacherDetails();
                    }
                    case "3" -> {
                        booking.showBookingDetails(0);
                    }
                    case "4" -> {
                        report.generateStudentReport(booking, student);
                    }
                    case "5" -> {
                        report.generateTeacherReport(review);
                    }
                    case "6" -> {
                        review.showReviewDetails(0);
                    }
                    case "7" -> {
                        userLogin();
                        status = "logout";
                    }
                }
            }
            //recall this function till status is not logout
            if (status == null || !status.equalsIgnoreCase("logout")) {
                openAdminPanel();
            }

        }

    }

    public static void main(String[] args) {
        HJJS_App app = new HJJS_App();
        app.schoolInfo();
        app.Start();
    }

}
