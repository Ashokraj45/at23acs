package hjjs_app;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportController {

    public void generateStudentReport(BookingManagement booking, Student student) {
        String studentName = null;
        int totalBookings = 0;
        int totalCancel = 0;
        int totalAttend = 0;
        int studentId = 0;
        String bookingId = null;
        String lessonCode = null;
        String teacherName = null;
        String lessonName = null;
        String bookingDate = null;
        String status = null;
        int id=0;
        if (!booking.getBookingDetails().isEmpty()) {
            List<BookingManagement> bookingDetails = booking.getBookingDetails();
            //show booking details
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("|\t\t\t\t\t\t\t\tStudent Booking Details\t\t\t\t\t\t\t\t|");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
             List<Student> studentDetails = student.getStudentDetails();
            for (Student student1 : studentDetails) {
                studentName = student1.getStuName();
                studentId = student1.getStuId();
                totalBookings = countStatus(bookingDetails, studentId, "Booked");
                totalCancel = countStatus(bookingDetails, studentId, "Cancel");
                totalAttend = countStatus(bookingDetails, studentId, "Attend");
                if (!(totalBookings == 0 && totalCancel == 0 && totalAttend == 0)) {
                    id++;
                    System.out.println("|\tRecord : "+id);
                    System.out.println("|\tStudent Id : " + student1.getStuId());
                    System.out.println("|\tStudent Level : " + student1.getStuLevel());
                    System.out.println("|\tStudent Name :" + studentName);
                    System.out.println("|\tStudent contact : " + student1.getStuContact());
                    System.out.println("|\tEmail : " + student1.getStuEmail());
                    System.out.println("|\tStudent Gender :  "+ student1.getStuGender());
                    System.out.println("|\tTotal Booking : " + totalBookings);
                    System.out.println("|\tTotal Attend : " + totalAttend);
                    System.out.println("|\tTotal Cancel : " + totalCancel);
                    System.out.println();
                    System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.printf("%-15s%-15s%-20s%-15s%-15s%-15s\n", "|\tBooking Id", "\t|\tLesson Code", "\t|\tLesson Name", "\t|\tTeacher Name", "\t|\tBooking Date", "\t|\tStatus\t|");
                    System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
                    for (BookingManagement booking1 : bookingDetails) {
                        if (booking1.getStuId() == student1.getStuId()) {
                            bookingId = booking1.getBookingId();
                            lessonCode = booking1.getLessonCode();
                            lessonName = booking1.getLessonName();
                            teacherName = booking1.getTeacherName();
                            bookingDate = booking1.getBookingDate();
                            status = booking1.getBookingStatus();
                            System.out.printf("%-15s%-15s%-20s%-15s%-15s%-15s\n", "|\t" + bookingId, "\t|\t" + lessonCode, "\t|\t" + lessonName, "\t|\t" + teacherName, "\t|\t" + bookingDate, "\t|\t" + status, "\t|");
                            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
                        }
                    }
                }
            }
        } else {
            System.out.println("Student report is empty");
        }
    }

    private int countStatus(List<BookingManagement> bookingDetails, int studentId, String status) {
        int count = 0;
        for (BookingManagement booking2 : bookingDetails) {
            if (booking2.getStuId() == studentId && booking2.getBookingStatus().equals(status)) {
                count++;
            }
        }
        return count;
    }

    public void generateTeacherReport(LessonReview ratingDetails) {
        if (!ratingDetails.getReviewDetails().isEmpty()) {
            System.out.println("---------------------------------------------------------------------------------"
                    + "------------------------------------------------------------------");
            System.out.println("|\t\t\t\t\t\t\t\tTeacher Review Details\t\t\t\t\t\t\t\t|");
            System.out.println("--------------------------------------------------------------------------------"
                    + "-------------------------------------------------------------------");
            //create map list to store total ratings and total attend lesson
            Map<String, Double> teacherRatings = new HashMap<>();
            Map<String, Integer> teacherCounts = new HashMap<>();

            // get rating details of each teacher
            for (Teacher teacher : new Teacher().getTeacherDetails()) {
                String teacherName = teacher.getFullName();

                double totalRating = 0.0;
                int count = 0;

                // Iterate through each rating detail
                for (LessonReview ratingData : ratingDetails.getReviewDetails()) {
                    if (ratingData.getTeacherName().equalsIgnoreCase(teacherName)) {
                        double rating = Double.parseDouble(ratingData.getRating());
                        totalRating += rating;
                        count++;
                    }
                }

                // Calculate average rating for the teacher
                if (count > 0) {
                    double averageRating = totalRating / count;
                    teacherRatings.put(teacherName, averageRating);
                    teacherCounts.put(teacherName, count);
                }
            }

            // Print average ratings for each teacher
            for (Map.Entry<String, Double> entry : teacherRatings.entrySet()) {
                String teacherName = entry.getKey();
                double averageRating = entry.getValue();
                int count = teacherCounts.get(teacherName);

                System.out.println("Teacher Name : " + teacherName);
                System.out.println("Average Rating : " + averageRating);
                System.out.println("--------------------------------------------------------------------------------"
                        + "-------------------------------------------------------------------");
                System.out.printf("%-15s%-15s%-15s%-15s%-15s%-15s%-15s%-15s%-15s\n", "| Review Code ", "| Student Name ",
                         "| Lesson Code ", "| Lesson Name ", "| Teacher ", "| Review Date ", "| Review Day ", "| Rating ", "Review Description");
                System.out.println("--------------------------------------------------------------------------------"
                        + "-------------------------------------------------------------------");

                // Print rating details for each teacher
                for (LessonReview ratingData : ratingDetails.getReviewDetails()) {
                    if (ratingData.getTeacherName().equalsIgnoreCase(teacherName)) {
                        String studentName = ratingData.getStudentName();
                        String lessonCode = ratingData.getLessonCode();
                        String lessonName = ratingData.getLessonName();
                        String reviewCode = (studentName.substring(0, 3) + lessonName.substring(0, 3) + "_0" + ratingData.getRatingId()).toUpperCase();
                        String ratingDate = ratingData.getRatingDate();
                        String ratingDay = ratingData.getRatingDay();
                        String rating = ratingData.getRating();
                        String reviewDescription = ratingData.getReview();

                        // Print rating detail
                        System.out.printf("%-15s%-15s%-15s%-15s%-15s%-15s%-15s%-15s%-15s\n", "| " + reviewCode, "| " + studentName, "| " + lessonCode, "| " + lessonName,
                                "| " + teacherName, "| " + ratingDate, "| " + ratingDay, "| " + rating, "| " + reviewDescription);
                    }
                }
                System.out.println("--------------------------------------------------------------------------------"
                        + "-------------------------------------------------------------------");
            }
        } else {
            System.out.println("No rating details available.");
        }
    }

}
