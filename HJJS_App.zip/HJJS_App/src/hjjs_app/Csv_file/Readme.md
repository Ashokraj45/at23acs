* admin contact and password for login
AdminContact=04123451234
admin password= 12345


*student contact and password for login
1.  contact=04123678129
    password =12345

2.  contact=04123679129
    password= 54321

3.  contact = 04123678127
    password=14352

4. contact=04123578129 //wrong
   password =12345

5. contact = 04123678124
   password=14325
