package hjjs_app;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class TeacherTest {

    private Student student;
    private LessonDetails lesson;
    private TimeTable timetable;
    private BookingManagement instance;
    private LessonReview review;
    private List<BookingManagement> bookings;

    public void preBookedLesson() {
        String lessonCode = "Fri_01";
        student = new Student();
        lesson = new LessonDetails();
        timetable = new TimeTable(lesson);
        instance = new BookingManagement(student, lesson, timetable);
        review = new LessonReview(student, instance);

        //pre booking class
        instance.lessonBooking(lessonCode, 1);
        instance.lessonBooking(lessonCode, 2);
        instance.lessonBooking(lessonCode, 3);
        instance.lessonBooking(lessonCode, 5);

    }

    @Test
    public void testCheckSeatCapacity() {
        System.out.println("Check selected lesson capacity");
        preBookedLesson();
        String lessonCode = "Fri_01";
        boolean expResult = false;
        boolean result = instance.checkSeatCapacity(lessonCode);
        assertEquals(expResult, result);

    }

    @Test
    public void testvalidLessonLevel() {
        System.out.println("Chcek lesson is suitable for student level");
        String lessonCode = "Fri_01";
        int studentId = 1;
        preBookedLesson();
        boolean expResult = true;
        boolean result = instance.isValidLevel(lessonCode, studentId);
        assertEquals(expResult, result);
        if(result){
            System.out.println("This class is suitable for student level");
        }
        
    }

    @Test
    public void testStudentLogin() {
        System.out.println("studentLogin");
        String contact = "04123678129";
        String password = "12345";
        int result = 0;
        Student instance = new Student();
        instance.preRegisteredStudents();
        List<Student> studentDetails = instance.getStudentDetails();
        for (Student student : studentDetails) {
            if (student.getStuContact().equals(contact) && student.getStuPassword().equals(password)) {
                result = student.getStuId();
            }
        }
        if (result != 0) {
            System.out.println("Login Successfully");
        }
        assertNotNull(result);
    }

    @Test
    public void testLessonBooking() {
        System.out.println("lessonBooking");
        String lessonCode = "Mon_12";
        int studentId = 1;
        preBookedLesson();
        // Check for duplicate booking
        if (instance.duplicateBoooking(lessonCode, studentId)) {
            System.out.println("This class has already  booked.");
        } else if (!instance.isValidLevel(lessonCode, studentId)) {
            System.out.println("This class is not for your level.");
        } else if (!instance.checkSeatCapacity(lessonCode)) {
            System.out.println("This lesson seat full");
        } else {
            // Get student details and lesson details to store in booking details
            String stuName = student.getStudentById(studentId).getStuName();
            String lessonName = lesson.getLesssonDetailsById(lessonCode).getLessonTitle();
            String bookingId = stuName.substring(0, 3).toUpperCase() + lessonName.substring(0, 3).toUpperCase() + "_" + (instance.getBookingDetails().size() + 1);
            int stuLevel = student.getStudentById(studentId).getStuLevel();
            String teacherName = lesson.getLesssonDetailsById(lessonCode).getLessonTeacher();
            int lessonLevel = lesson.getLesssonDetailsById(lessonCode).getLessonLevel();
            String bookingDate = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
            String status = "Booked";
            // Add the booking to the bookingDetails list
            List<BookingManagement> bookingDetails = new ArrayList<>();
            bookingDetails.add(new BookingManagement(bookingId, studentId, stuName, stuLevel, lessonCode, lessonName, teacherName, lessonLevel, bookingDate, status));
            instance.setBookingDetails(bookingDetails);
            // Update lesson seat after booking class
            for (LessonDetails lesson1 : lesson.getLessons()) {
                if (lesson1.getLessonCode().equalsIgnoreCase(lessonCode)) {
                    int currentSeat = Integer.parseInt(lesson1.getNumOfSeats());
                    int updatedSeat = currentSeat - 1;
                    lesson1.setNumOfSeats(String.valueOf(updatedSeat));
                    break;
                }
            }
            System.out.println("Class booked successfull.");
        }
        List<BookingManagement> result = instance.getBookingDetails();
        assertNotNull(result);
        instance.showBookingDetails(studentId);

    }

    @Test
    public void testSetReview() {
        String lessonCode = "Fri_01";
        int studentId = 1;
        String bookingId = "JAMFLO_1";
        String rating = "5";
        String review1 = "best class";
        preBookedLesson();
        instance.showBookingDetails(studentId);
        //attend class after booking
        for (BookingManagement booking : instance.getBookingDetails()) {
            if (booking.getBookingId().equalsIgnoreCase(bookingId)) {
                lessonCode = booking.getLessonCode();
                // check selected bookingid status
                if (booking.getBookingStatus().equalsIgnoreCase("Attend") || booking.getBookingStatus().equalsIgnoreCase("Cancel")) {
                    System.out.println("This booking id is already attended or cancelled.");
                } else {
                    //store review details in arraylist
                    review.saveReviewDetails(studentId, bookingId, rating, review1);
                    booking.setBookingStatus("Attend");
                    // Update lesson seat after booking class
                    for (LessonDetails lesson1 : lesson.getLessons()) {
                        if (lesson1.getLessonCode().equalsIgnoreCase(lessonCode)) {
                            int currentSeat = Integer.parseInt(lesson1.getNumOfSeats());
                            int updatedSeat = currentSeat + 1;
                            lesson1.setNumOfSeats(String.valueOf(updatedSeat));
                            break;
                        }
                    }

                    //update level after attend class
                    int lessonLevel = lesson.getLesssonDetailsById(lessonCode).getLessonLevel();
                    int stuCurrentLevel = student.getStudentById(studentId).getStuLevel();
                    if (lessonLevel > stuCurrentLevel) {
                        for (Student student1 : student.getStudentDetails()) {

                            if (student1.getStuId() == studentId) {
                                student1.setStuLevel(lessonLevel);
                                break;
                            }
                        }
                    }

                    System.out.println("Class attend successfully");
                }
            }
        }
        List<LessonReview> result = review.getReviewDetails();
        assertNotNull(result);
        review.showReviewDetails(studentId);
    }

    @Test
    public void testFilterTimeTableByTeacher() {
        preBookedLesson();
        String teacherName = "Carter";
        //validation of teacher is exist or not
        if (timetable.isTeacherExist(teacherName)) {
            //clear time table before adding new details
            List<LessonDetails> filter = new ArrayList<>();
            for (LessonDetails lesson1 : new LessonDetails().getLessons()) {
                //get lesson detais by teacher name
                if (lesson1.getLessonTeacher().equalsIgnoreCase(teacherName)) {
                    //add new details in filterTimeTable
                    filter.add(lesson1);
                    timetable.setFilterTimeTable(filter);
                }
            }
            List<LessonDetails> result = timetable.getFilterTimeTable();
            assertNotNull(result);

        } else {
            //show error message after enter wrong teacher name by user
            System.out.println("Enter valid Teacher Name");
        }
    }

}
